function openModal(img) {
    const modal = document.getElementById("myModal");
    const modalImg = document.getElementById("modalImg");
    
    modal.style.display = "block";
    modalImg.src = img.src; // Set the source of the modal image to the clicked image
}

function closeModal() {
    const modal = document.getElementById("myModal");
    modal.style.display = "none"; // Hide the modal
}